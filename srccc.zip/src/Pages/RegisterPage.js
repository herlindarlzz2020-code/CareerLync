
import React, { useState } from "react";
import { Form, Button, Container, Card, ToggleButton, ButtonGroup } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import API_BASE_URL from "../apiConfig";
import "./AuthPages.css";

const RegisterPage = () => {
  const navigate = useNavigate();
  const [role, setRole] = useState("jobseeker");
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      alert("Passwords do not match");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch(`${API_BASE_URL}/api/Auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          password: formData.password,
          role,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        alert("Registration successful! Please login.");
        navigate("/login");
      } else {
        alert(data.message || "Registration failed");
      }
    } catch (error) {
      alert("Error connecting to server");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <Container className="d-flex justify-content-center align-items-center min-vh-100">
        <Card className="auth-card shadow-lg p-4">
          <h2 className="text-center fw-bold mb-4">Register</h2>

          {/* Role Toggle */}
          <ButtonGroup className="mb-4 w-100">
            <ToggleButton
              id="jobseeker-radio"
              type="radio"
              variant={role === "jobseeker" ? "primary" : "outline-primary"}
              name="role"
              value="jobseeker"
              checked={role === "jobseeker"}
              onChange={(e) => setRole(e.currentTarget.value)}
            >
              Jobseeker
            </ToggleButton>
            <ToggleButton
              id="employer-radio"
              type="radio"
              variant={role === "employer" ? "success" : "outline-success"}
              name="role"
              value="employer"
              checked={role === "employer"}
              onChange={(e) => setRole(e.currentTarget.value)}
            >
              Employer
            </ToggleButton>
          </ButtonGroup>

          {/* Form */}
          <Form onSubmit={handleRegister}>
            <Form.Group className="mb-3">
              <Form.Label>Name</Form.Label>
              <Form.Control
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Enter full name"
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Email</Form.Label>
              <Form.Control
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="Enter email"
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Password</Form.Label>
              <Form.Control
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                placeholder="Enter password"
                required
              />
            </Form.Group>
            <Form.Group className="mb-4">
              <Form.Label>Confirm Password</Form.Label>
              <Form.Control
                type="password"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                placeholder="Re-enter password"
                required
              />
            </Form.Group>
            <Button type="submit" variant="success" className="w-100 mb-3" disabled={loading}>
              {loading ? "Registering..." : "Register"}
            </Button>
          </Form>
        </Card>
      </Container>
    </div>
  );
};

export default RegisterPage;