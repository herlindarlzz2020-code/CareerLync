import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Form, Button, Table, Card, Alert } from 'react-bootstrap';
import axios from 'axios';
import jwtDecode from 'jwt-decode';

const JobSeekerDashboard = () => {
  const [profile, setProfile] = useState(null);
  const [resume, setResume] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [filteredJobs, setFilteredJobs] = useState([]);
  const [applications, setApplications] = useState([]);
  const [searchParams, setSearchParams] = useState({ title: '', location: '', industry: '' });
  const [resumeFile, setResumeFile] = useState(null);
  const [userId, setUserId] = useState(null);
  const [jobSeekerId, setJobSeekerId] = useState(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Fetch userId from token and profile on mount
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      setError('Please log in to access the dashboard.');
      return;
    }

    try {
      const decoded = jwtDecode(token);
      const userIdFromToken = decoded['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier'];
      setUserId(userIdFromToken);

      // Fetch profile by userId
      axios.get(`/api/JobSeekers/user/${userIdFromToken}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
        .then(response => {
          setProfile(response.data);
          setJobSeekerId(response.data.jobSeekerID);
        })
        .catch(() => {
          setProfile({ firstName: '', lastName: '', phone: '', qualification: '', skills: '' }); // For create
        });
    } catch (err) {
      setError('Invalid token. Please log in again.');
    }
  }, []);

  // Fetch resume, jobs, applications when jobSeekerId changes
  useEffect(() => {
    if (jobSeekerId) {
      const token = localStorage.getItem('token');

      // Fetch resume (assuming endpoint /api/Resumes/byJobSeeker/{jobSeekerId})
      axios.get(`/api/Resumes/byJobSeeker/${jobSeekerId}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
        .then(response => setResume(response.data[0])) // Assume first resume
        .catch(() => setResume(null));

      // Fetch all jobs
      axios.get('/api/Job', {
        headers: { Authorization: `Bearer ${token}` }
      })
        .then(response => setJobs(response.data))
        .catch(() => setError('Error fetching jobs.'));

      // Fetch applications (assuming endpoint /api/Applications/byJobSeeker/{jobSeekerId})
      axios.get(`/api/Applications/byJobSeeker/${jobSeekerId}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
        .then(response => setApplications(response.data))
        .catch(() => setError('Error fetching applications.'));
    }
  }, [jobSeekerId]);

  // Handle profile create/update
  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    const dto = {
      userId,
      firstName: profile.firstName,
      lastName: profile.lastName,
      phone: profile.phone,
      qualification: profile.qualification,
      skills: profile.skills
    };

    try {
      if (jobSeekerId) {
        // Update
        const response = await axios.put(`/api/JobSeekers/${jobSeekerId}`, dto, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setProfile(response.data);
      } else {
        // Create
        const response = await axios.post('/api/JobSeekers', dto, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setProfile(response.data);
        setJobSeekerId(response.data.jobSeekerID);
      }
      setSuccess('Profile saved successfully.');
    } catch (err) {
      setError('Error saving profile.');
    }
  };

  // Handle resume upload (assuming endpoint /api/Resumes/upload)
  const handleResumeUpload = async (e) => {
    e.preventDefault();
    if (!resumeFile) return;

    const token = localStorage.getItem('token');
    const formData = new FormData();
    formData.append('file', resumeFile);
    formData.append('jobSeekerId', jobSeekerId);

    try {
      const response = await axios.post('/api/Resumes/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          Authorization: `Bearer ${token}`
        }
      });
      setResume(response.data);
      setSuccess('Resume uploaded successfully.');
    } catch (err) {
      setError('Error uploading resume.');
    }
  };

  // Handle job search (client-side filter)
  const handleSearch = (e) => {
    e.preventDefault();
    const filtered = jobs.filter(job =>
      (searchParams.title ? job.title.toLowerCase().includes(searchParams.title.toLowerCase()) : true) &&
      (searchParams.location ? job.location.toLowerCase().includes(searchParams.location.toLowerCase()) : true) &&
      (searchParams.industry ? job.qualifications.toLowerCase().includes(searchParams.industry.toLowerCase()) : true) // Assume industry in qualifications or add if needed
    );
    setFilteredJobs(filtered);
  };

  // Handle apply to job (assuming endpoint /api/Applications)
  const handleApply = async (jobId) => {
    if (!resume) {
      setError('Please upload a resume before applying.');
      return;
    }

    const token = localStorage.getItem('token');
    const dto = {
      jobId,
      jobSeekerId
    };

    try {
      await axios.post('/api/Applications', dto, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setSuccess('Application submitted successfully.');
      // Refresh applications
      const response = await axios.get(`/api/Applications/byJobSeeker/${jobSeekerId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setApplications(response.data);
    } catch (err) {
      setError('Error submitting application.');
    }
  };

  if (error) {
    return <Alert variant="danger">{error}</Alert>;
  }

  if (!profile) {
    return <Alert variant="info">Loading profile...</Alert>;
  }

  return (
    <Container className="my-5">
      {success && <Alert variant="success">{success}</Alert>}
      <h2>JobSeeker Dashboard</h2>
      <Row>
        <Col md={6}>
          <h4>{jobSeekerId ? 'Update Profile' : 'Create Profile'}</h4>
          <Form onSubmit={handleProfileSubmit}>
            <Form.Group className="mb-3">
              <Form.Label>First Name</Form.Label>
              <Form.Control
                type="text"
                value={profile.firstName}
                onChange={(e) => setProfile({ ...profile, firstName: e.target.value })}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Last Name</Form.Label>
              <Form.Control
                type="text"
                value={profile.lastName}
                onChange={(e) => setProfile({ ...profile, lastName: e.target.value })}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Phone</Form.Label>
              <Form.Control
                type="tel"
                value={profile.phone}
                onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Qualification</Form.Label>
              <Form.Control
                type="text"
                value={profile.qualification}
                onChange={(e) => setProfile({ ...profile, qualification: e.target.value })}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Skills (comma-separated)</Form.Label>
              <Form.Control
                type="text"
                value={profile.skills}
                onChange={(e) => setProfile({ ...profile, skills: e.target.value })}
                required
              />
            </Form.Group>
            <Button variant="primary" type="submit">
              {jobSeekerId ? 'Update Profile' : 'Create Profile'}
            </Button>
          </Form>

          <h4 className="mt-4">Resume</h4>
          {resume && (
            <a href={resume.resumePath} target="_blank" rel="noopener noreferrer">
              View Uploaded Resume (Uploaded on {new Date(resume.uploadedAt).toLocaleDateString()})
            </a>
          )}
          <Form onSubmit={handleResumeUpload} className="mt-2">
            <Form.Group className="mb-3">
              <Form.Label>Upload/Replace Resume</Form.Label>
              <Form.Control
                type="file"
                accept=".pdf,.doc,.docx"
                onChange={(e) => setResumeFile(e.target.files[0])}
              />
            </Form.Group>
            <Button variant="primary" type="submit" disabled={!resumeFile}>
              Upload Resume
            </Button>
          </Form>
        </Col>
        <Col md={6}>
          <h4>Search Jobs</h4>
          <Form onSubmit={handleSearch}>
            <Form.Group className="mb-3">
              <Form.Label>Title</Form.Label>
              <Form.Control
                type="text"
                value={searchParams.title}
                onChange={(e) => setSearchParams({ ...searchParams, title: e.target.value })}
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Location</Form.Label>
              <Form.Control
                type="text"
                value={searchParams.location}
                onChange={(e) => setSearchParams({ ...searchParams, location: e.target.value })}
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Industry (in Qualifications)</Form.Label>
              <Form.Control
                type="text"
                value={searchParams.industry}
                onChange={(e) => setSearchParams({ ...searchParams, industry: e.target.value })}
              />
            </Form.Group>
            <Button variant="primary" type="submit">Search</Button>
          </Form>
          <div className="mt-4">
            {(filteredJobs.length > 0 ? filteredJobs : jobs).map(job => (
              <Card key={job.jobId} className="mb-3">
                <Card.Body>
                  <Card.Title>{job.title}</Card.Title>
                  <Card.Text>{job.description}</Card.Text>
                  <Card.Text><strong>Location:</strong> {job.location}</Card.Text>
                  <Card.Text><strong>Salary:</strong> {job.salary}</Card.Text>
                  <Card.Text><strong>Company:</strong> {job.companyName}</Card.Text>
                  <Card.Text><strong>Qualifications:</strong> {job.qualifications}</Card.Text>
                  <Button variant="success" onClick={() => handleApply(job.jobId)}>Apply</Button>
                </Card.Body>
              </Card>
            ))}
          </div>
        </Col>
      </Row>
      <Row className="mt-5">
        <Col>
          <h4>My Applications</h4>
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>Job Title</th>
                <th>Status</th>
                <th>Applied On</th>
              </tr>
            </thead>
            <tbody>
              {applications.map(app => (
                <tr key={app.applicationId}>
                  <td>{app.job?.title || 'N/A'}</td>
                  <td>{app.status}</td>
                  <td>{new Date(app.appliedAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Col>
      </Row>
    </Container>
  );
};

export default JobSeekerDashboard;