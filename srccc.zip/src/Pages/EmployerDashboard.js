import React from "react";
import { Button, Container, Row, Col, Card } from "react-bootstrap";
import { Link } from "react-router-dom";
import { BriefcaseFill, PencilSquare,PeopleFill } from "react-bootstrap-icons";
import "bootstrap/dist/css/bootstrap.min.css";
import "./Dashboard.css";

const EmployerDashboard = () =>{
return(
    <div className="dashboard-page">
        <Container>
            <h1 className="dashboard-title text-center mb-5">Employer Dashboard</h1>
            <Row className="g-4">
             <Col md={4}>
             <Card className="dashboard-card shadow-sm text-center p-4">
                <BriefcaseFill size={40} className="mb-3 text-primary" />
                <h4>Post a Job</h4>
                <p>Create and publish new job listings to attract talent.</p>
                <Button as={Link} to="/employer/post-job" varient="primary"> Create Job</Button>

                </Card>
                </Col>
                <Col md={4}>
                <Card className="dashboard-card shadow-sm text-center p-4">
                    <PencilSquare size={40} className="mb-3 text-success" />
                    <h4>Manage Listings</h4>
                    <p>Edit, Update or Remove your existing job listings.</p>
                    <Button as={Link} to="/employer/manage-jobs" varient="success">Manage Jobs</Button>
                    </Card>
                    </Col>
                    <Col md={4}>
                    <Card className="dashboard-card shadow-sm text-center p-4">
                    <PeopleFill size={40} className="mb-3 text-warning" />
                        <h4>View applicants</h4>
                        <p>Review candidate profiles and track application progress</p>
                        <Button as={Link} to="/employer/view-applicants" varient="warning"> View Applications</Button>
                     
                    </Card>
                    
                    
                </Col>
            </Row>
        </Container>

    </div>
);
};
export default EmployerDashboard;