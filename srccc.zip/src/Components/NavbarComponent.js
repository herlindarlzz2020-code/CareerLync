import React from 'react';
import { Navbar, Nav, Container } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';

function NavbarComponent()
{
    return(
        <Navbar style={{backgroundColor:'#0D6EFD'}} varient="dark" expand="lg" sticky="top" className="shadow-sm">
            <Container>

                <Navbar.Brand as ={Link} to="/" style={{fontWeight:'bold',fontSize:'1.5rem'}}>CareerLync</Navbar.Brand>
                <Navbar.Toggle aria-controls="navbar-nav" />
                    <Navbar.Collapse id="navbar-nav">
                        <Nav className="ms-auto">
                            
                            <Nav.Link as={Link} to="/" style={{fontSize:'1.1rem'}}>Home</Nav.Link>
                            <Nav.Link as={Link} to="/login" style={{fontSize:'1.1rem'}}>Login</Nav.Link>
                            <Nav.Link as={Link} to="/register" style={{fontSize:'1.1rem'}}>Register</Nav.Link>
                        </Nav>
                    </Navbar.Collapse>

            </Container>
        </Navbar>
    );
}

export default NavbarComponent;