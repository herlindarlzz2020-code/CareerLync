import React from 'react';
import {  Container } from 'react-bootstrap';

function FooterComponent(){
    return(
        <footer className="text-white  py-3" style={{backgroundColor:'#0D6EFD'}}>
            <Container className="text-center">
                <p className="mb-0">&copy;{new Date().getFullYear()}CareerLync. All Rights Reserved.</p>

                <small>
                    Connecting Employers & JobSeekers with Opportunities
                </small>

            </Container>
        </footer>
    );
}
export default FooterComponent;