import React from 'react';
import './App.css';
import { BrowserRouter as Router,Routes,Route } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import NavbarComponent from './Components/NavbarComponent';
import FooterComponent from './Components/FooterComponent';
import HomePage from './Pages/HomePage';
import LoginPage from './Pages/LoginPage';
import RegisterPage from './Pages/RegisterPage';
import EmployerDashboard from './Pages/EmployerDashboard';
import JobSeekerDashboard from './Pages/JobSeekerDashboard';

function App()
{
  return(
    <Router>
      <div className="app-container">
      <NavbarComponent />
      <HomePage />
      <LoginPage />
      <RegisterPage />
      <EmployerDashboard />
      <JobSeekerDashboard />
         <div className="content-wrap">
          </div>
          <FooterComponent />
         
      </div>
         
    </Router>
    
    
  
  );
}

export default App;